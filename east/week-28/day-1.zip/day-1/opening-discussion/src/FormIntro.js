const FormIntro = () => {
  return <div>FormIntro</div>;
};

export default FormIntro;
