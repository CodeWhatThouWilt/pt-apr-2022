function App() {
  return (
    <h1>Hello from App</h1>
  );
}

export default App;